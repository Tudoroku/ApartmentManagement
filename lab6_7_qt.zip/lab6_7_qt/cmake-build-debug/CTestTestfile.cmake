# CMake generated Testfile for 
# Source directory: D:/OOP/lab6_7_qt_start/lab6_7_qt
# Build directory: D:/OOP/lab6_7_qt_start/lab6_7_qt/cmake-build-debug
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[lab6_7_tests]=] "D:/OOP/lab6_7_qt_start/lab6_7_qt/cmake-build-debug/lab6_7_tests.exe")
set_tests_properties([=[lab6_7_tests]=] PROPERTIES  _BACKTRACE_TRIPLES "D:/OOP/lab6_7_qt_start/lab6_7_qt/CMakeLists.txt;59;add_test;D:/OOP/lab6_7_qt_start/lab6_7_qt/CMakeLists.txt;0;")
