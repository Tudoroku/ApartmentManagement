# Additional clean files
cmake_minimum_required(VERSION 3.16)

if("${CONFIG}" STREQUAL "" OR "${CONFIG}" STREQUAL "Debug")
  file(REMOVE_RECURSE
  "CMakeFiles\\lab6_7_qt_autogen.dir\\AutogenUsed.txt"
  "CMakeFiles\\lab6_7_qt_autogen.dir\\ParseCache.txt"
  "CMakeFiles\\run_tests_autogen.dir\\AutogenUsed.txt"
  "CMakeFiles\\run_tests_autogen.dir\\ParseCache.txt"
  "lab6_7_qt_autogen"
  "run_tests_autogen"
  )
endif()
